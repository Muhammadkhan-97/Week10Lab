package filters;

import dataaccess.UserDB;
import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import models.User;

public class AdminFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

        // code that is executed before the servlet
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpSession session = httpRequest.getSession();
        User user = (User) session.getAttribute("user");

        System.out.println(user);

        // check if the user is an admin
        if (user.getRole().getRoleId() == 1) {
            RequestDispatcher dispatcher = request.getRequestDispatcher("admin");
            dispatcher.forward(request, response);
            return;
        } else {
            RequestDispatcher dispatcher = request.getRequestDispatcher("notes");
            dispatcher.forward(request, response);
        }

        chain.doFilter(request, response); // execute the servlet

        // code that is executed after the servlet
    }

    @Override
    public void destroy() {
    }

    private boolean isAdmin(User user) {
        return user != null && user.getRole() != null && user.getRole().getRoleId() == 1;
    }

}
